/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package par.o.impar;

import java.util.Scanner;

/**
 *
 * @author EJMA
 */
public class ParOImpar {

 
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.println("Ingrese un numero par o impar"); // solicitamos el numero al usuario
        int numero = s.nextInt(); // almacenamos el numero del usuario
        
        
       // validacion si es par o impar 
       
       if (numero % 2 == 0){ // condicion que me permite validar si es impar o par por el modulo % 
            
           System.out.println("Este numero es par " + numero);
           
       } else {
           System.out.println("Este numero es impar " + numero);
       }
    }
    
}
