﻿//CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS Y QUE ESTA FUNCIÓN GENERE Y MUESTRE EN PANTALLA LA TABLA DE MULTIPLICAR DEL PRIMER DÍGITO, SIENDO EL LÍMITE DE LA TABLA EL SEGUNDO DÍGITO.


using System;

class Program
{

    public static void Main(string[] args)
    {

        Console.WriteLine("Ingrese un nummero entero");
        int numero = Convert.ToInt32(Console.ReadLine());

        Console.Clear(); 

        if (numero < 10 || numero >= 100){

            Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");

        } 
    
        else{

        int resultado = Entero(numero);
        Console.ReadLine();


    } }

    public static int Entero(int numero)
    {
        int resultado = 0;
        int modulo;
        int divi; 

        divi = numero / 10;
        modulo = numero % 10;

        for(int i = 0; i <= modulo; i++){

            resultado = i * divi;

            Console.WriteLine($"Su tabla de multiplicacion es {divi} * {i} = {resultado}" );

        }


        return resultado ;

    }
    


}

// modulo = numero % 10;

        // do {

        //     resultado = numero * modulo;
        //  Console.WriteLine($"Su tabla de multiplicacion es {numero} * {modulo} = {resultado}" );
        // }while (numero < modulo);