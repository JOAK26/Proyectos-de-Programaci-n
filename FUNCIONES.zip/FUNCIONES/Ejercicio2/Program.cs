﻿//CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS Y RETORNE SU ÚLTIMO DÍGITO.


using System;

class Program
{

    public static void Main(string[] args)
    {

        Console.WriteLine("Ingrese un nummero entero");
        int numero = Convert.ToInt32(Console.ReadLine());

        Console.Clear();

        if (numero < 10 || numero >= 100){

            Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");

        } 
    
        else{

        int resultado = Entero(numero);
        Console.WriteLine("El último dígito es: " + resultado);
        Console.ReadLine();


    } }

    public static int Entero(int numero)
    {

        int modulo;

        modulo = numero % 10;

        return modulo;

    }
    


}