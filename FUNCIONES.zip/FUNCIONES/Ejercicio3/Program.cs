﻿//CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN NUMERO Y RETORNE UN MENSAJE DICIENDO SI ES PAR O IMPAR, SEGÚN SEA EL CASO.

 using System;

class Program
{

    public static void Main(string[] args)
    {

        Console.WriteLine("Ingrese un nummero entero");
        int numero = Convert.ToInt32(Console.ReadLine());

        
        Console.Clear();

        int resultado = Entero(numero);
        Console.ReadLine();

        Thread.Sleep(300);
        Console.WriteLine("BYE");

    } 

    public static int Entero(int numero)
    {

        if (numero % 2 == 0){

            Console.WriteLine ("Su numero ingresado es par " + numero);

        } else{ 
            Console.WriteLine ("Su numero ingresado es impar " + numero);
        }

        return numero;

    }
    



}