﻿//CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS. LA FUNCIÓN DEBE RETORNAR EL MAYOR DE LOS DOS DÍGITOS.

using System;

class Program
{

    public static void Main(string[] args)
    {

        Console.WriteLine("Ingrese un nummero entero");
        int numero = Convert.ToInt32(Console.ReadLine());

        Console.Clear();

        if (numero < 10 || numero >= 100)
        {

            Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");

        }

        else
        {

            int resultado = Entero(numero);
            Console.WriteLine("Este numero es mayor " + resultado);
            Console.ReadLine();
        }
    }

    public static int Entero(int numero)
    {
        int resultado;
        int modulo;
        int divi;

        divi = numero / 10;
        modulo = numero % 10;


        if (divi <= modulo)
        {

            resultado = modulo;

        }
        else
        {
            resultado = divi;

        }

        return resultado;
    }

}




