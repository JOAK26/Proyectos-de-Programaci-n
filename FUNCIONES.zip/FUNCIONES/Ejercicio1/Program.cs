﻿//CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UNA CADENA (EL NOMBRE DEL USUARIO) LA FUNCIÓN DEBE RETORNAR UN SALUDO QUE INCLUYA EL NOMBRE DEL USUARIO QUE RECIBIÓ.



using System;

class Program {

    public static void Main (string[]args){

        Saludar ("Esteban Josue");
        Console.ReadLine();
   
    }


    public static void Saludar  (string nombre){

        Console.WriteLine("Hola!" + nombre);

    }
}