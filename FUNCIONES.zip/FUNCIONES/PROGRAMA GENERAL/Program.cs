﻿// [1]  CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UNA CADENA (EL NOMBRE DEL USUARIO) LA FUNCIÓN DEBE RETORNAR UN SALUDO QUE INCLUYA EL NOMBRE DEL USUARIO QUE RECIBIÓ.
// [2] CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS Y RETORNE SU ÚLTIMO DÍGITO. 
// [3] CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN NUMERO Y RETORNE UN MENSAJE DICIENDO SI ES PAR O IMPAR, SEGÚN SEA EL CASO.
// [4] CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS Y QUE ESTA FUNCIÓN GENERE Y MUESTRE EN PANTALLA LA TABLA DE MULTIPLICAR DEL PRIMER DÍGITO, SIENDO EL LÍMITE DE LA TABLA EL SEGUNDO DÍGITO. 
// [5] CONSTRUIR UNA FUNCIÓN QUE RECIBA COMO PARÁMETRO UN ENTERO DE DOS DÍGITOS. LA FUNCIÓN DEBE RETORNAR EL MAYOR DE LOS DOS DÍGITOS.

using System;
using System.Diagnostics;

class Program
{

    public static void Main(string[] args)
    {


        bool continuar = true;

        while (continuar)
        {
            Console.ForegroundColor = (ConsoleColor.DarkRed);
            Console.WriteLine("Seleccione una opción:");
            Console.WriteLine("1 - Saludar al usuario");
            Console.WriteLine("2 - Obtener el último dígito de un número");
            Console.WriteLine("3 - Determinar si un número es par o impar");
            Console.WriteLine("4 - Mostrar la tabla de multiplicar del primer dígito de un número de dos dígitos");
            Console.WriteLine("5 - Obtener el mayor de los dos dígitos de un número");
            Console.WriteLine("6 - Salir");


            int opcion = Convert.ToInt32(Console.ReadLine());


            switch (opcion)
            {

                case 1:
                    // Requerimiento 1: Saludo con el nombre del usuario
                    Saludar("Esteban Josue");
                    Console.ReadLine();
                    break;


                case 2:
                    // Requerimiento 2: Obtener el último dígito de un número de dos dígitos
                    Console.WriteLine("Ingrese un nummero entero");
                    int numero = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();
                    if (numero < 10 || numero >= 100)
                    {
                        Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");
                    }
                    else
                    {
                        int resultado = Entero(numero);
                        Console.WriteLine("El último dígito es: " + resultado);
                        Console.ReadLine();
                    }

                    break;

                case 3:
                    // Requerimiento 3: Determinar si un número es par o impar
                    Console.WriteLine("Ingrese un nummero entero");
                    int numero1 = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();
                    int resultado1 = Entero1(numero1);
                    Console.ReadLine();
                    Thread.Sleep(300);
                    Console.WriteLine("BYE");
                    break;

                case 4:
                    // Requerimiento 4: Generar y mostrar la tabla de multiplicar
                    Console.WriteLine("Ingrese un nummero entero");
                    int numero2 = Convert.ToInt32(Console.ReadLine());
                    Console.Clear();
                    if (numero2 < 10 || numero2 >= 100)
                    {
                        Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");
                    }
                    else
                    {
                        int resultado3 = Entero2(numero2);
                        Console.ReadLine();
                    }
                    break;


                case 5:
                    // Requerimiento 5: Retornar el mayor de los dos dígitos
                    Console.WriteLine("Ingrese un nummero entero");
                    int numero4 = Convert.ToInt32(Console.ReadLine());

                    Console.Clear();

                    if (numero4 < 10 || numero4 >= 100)
                    {

                        Console.WriteLine("Ingrese un numero mayor que 10 y menor que 99");

                    }

                    else
                    {

                        int resultado4 = Entero5(numero4);
                        Console.WriteLine("Este numero es mayor " + resultado4);
                        Console.ReadLine();
                    }
                    break;

                case 6:
                    continuar = false;
                    Console.WriteLine("Saliendo del programa...");
                    break;

                default:
                    Console.WriteLine("Opción no válida. Por favor, intente nuevamente.");
                    break;


            }
            Console.WriteLine();
        }
    }




    // Función 1: Saludar al usuario
    public static void Saludar(string nombre)
    {

        Console.WriteLine("Hola!" + nombre);

    }

    // Función 2: Retornar el último dígito de un número de dos dígitos
    public static int Entero(int numero)
    {

        int modulo;

        modulo = numero % 10;

        return modulo;
    }


    // Función 3: Determinar si un número es par o impar
    public static int Entero1(int numero1)
    {

        if (numero1 % 2 == 0)
        {

            Console.WriteLine("Su numero ingresado es par " + numero1);

        }
        else
        {
            Console.WriteLine("Su numero ingresado es impar " + numero1);
        }

        return numero1;

    }


    // Función 4: Generar y mostrar la tabla de multiplicar



    public static int Entero2(int numero2)
    {
        int resultado3 = 0;
        int modulo1;
        int divi1;

        divi1 = numero2 / 10;
        modulo1 = numero2 % 10;

        for (int i = 0; i <= modulo1; i++)
        {

            resultado3 = i * divi1;

            Console.WriteLine($"Su tabla de multiplicacion es {divi1} * {i} = {resultado3}");

        }


        return resultado3;

    }

    // Función 5: Retornar el mayor de los dos dígitos

    public static int Entero5(int numero4)
    {
        int resultado4;
        int modulo2;
        int divi2;

        divi2 = numero4 / 10;
        modulo2 = numero4 % 10;


        if (divi2 <= modulo2)
        {

            resultado4 = modulo2;

        }
        else
        {
            resultado4 = divi2;

        }

        return resultado4;
    }



}

