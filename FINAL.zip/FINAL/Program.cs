﻿using System;
using System.Collections.Generic;
using System.IO;

public class Propietario
{
    public string RegistroPlaca { get; set; }
    public string Chasis { get; set; }
    public string EstatusVehiculo { get; set; }
    public string TipoEmision { get; set; }
    public string TipoVehiculo { get; set; }
    public string Marca { get; set; }
    public string Modelo { get; set; }
    public int AnosDeFabricacion { get; set; }
    public string FuerzaMotriz { get; set; }
    public int Cilindros { get; set; }
    public string NombreRazonSocial { get; set; }
    public string Direccion { get; set; }
    public string CedulaOPasaporte { get; set; }
    public DateTime FechaExpiracion { get; set; }

    public Propietario(string registroPlaca, string chasis, string estatusVehiculo, string tipoEmision, string tipoVehiculo,
                       string marca, string modelo, int anosDeFabricacion, string fuerzaMotriz, int cilindros,
                       string nombreRazonSocial, string direccion, string cedulaOPasaporte, DateTime fechaExpiracion)
    {
        RegistroPlaca = registroPlaca;
        Chasis = chasis;
        EstatusVehiculo = estatusVehiculo;
        TipoEmision = tipoEmision;
        TipoVehiculo = tipoVehiculo;
        Marca = marca;
        Modelo = modelo;
        AnosDeFabricacion = anosDeFabricacion;
        FuerzaMotriz = fuerzaMotriz;
        Cilindros = cilindros;
        NombreRazonSocial = nombreRazonSocial;
        Direccion = direccion;
        CedulaOPasaporte = cedulaOPasaporte;
        FechaExpiracion = fechaExpiracion;
    }

    public override string ToString()
    {
        return $"Placa: {RegistroPlaca}\nChasis: {Chasis}\nEstatus del Vehículo: {EstatusVehiculo}\nTipo de Emisión: {TipoEmision}\nTipo de Vehículo: {TipoVehiculo}\n" +
               $"Marca: {Marca}\nModelo: {Modelo}\nAño de Fabricación: {AnosDeFabricacion}\nFuerza Motriz: {FuerzaMotriz}\nCilindrada: {Cilindros} cilindros\n" +
               $"Propietario o Razón Social: {NombreRazonSocial}\nDirección: {Direccion}\nCédula o Pasaporte: {CedulaOPasaporte}\nFecha de Expiración: {FechaExpiracion.ToShortDateString()}";
    }
}

class Program
{
    static List<KeyValuePair<string, Propietario>> matriculas = new List<KeyValuePair<string, Propietario>>();


    static void Main()
    {
        // Mostrar el nuevo menú
        MostrarMenu();



        static void MostrarMenu()
        {
            string[] Vehicle = new string[7]
            {
            "7MMF'   `7MF'         `7MM          db           `7MM               ",
            " `MA     ,V             MM                         MM               ",
            "  VM:   ,V    .gPTYa    MMpMMMb.  `7MM   ,p6mbo    MM   .gPmYa      ",
            "   MM.  M'   ,M'   Yb   MM    MM    MM  6M'  OO    MM  ,M'   Yb     ",
            "   `MM A'    8Mmmmmmm   MM    MM    MM  8M         MM  8Mmmmmmm     ",
            "    :MM;     YM.    ,   MM    MM    MM  YM.    ,   MM  YM.    ,     ",
            "     VF       `Mbmmd' .JMML  JMML..JMML. YMbmd'  .JMML. `Mbmmd'     "
            };

            string[] Registration = new string[9]
            {
            "7MMxxxxMq.                     db            mm                        mm      db                          ",
            "MM   `MM.                                    MM                        MM                                  ",
            "MM   ,M9   .gPwYa   .PwYbmmm `7MM  ,pPmYbd mmMMmm  `7Mb,od8  ,6kYb.  mmMMmm  `7MM   ,pWmWq.  `7MMpMMMb.    ",
            "MMmmdM9   ,M'   Yb :MI  I8     MM  8I   `h   MM      MM' H' 8)   MM    MM      MM  6W'   `Wb   MM    MM    ",
            "MM  YM.   8Mwwwwww  WmmmP      MM  `YMMMa.   MM      MM      ,pm9MM    MM      MM  8M     M8   MM    MM    ",
            "MM   `Mb. YM.    , 8M          MM  L.   I8   MM      MM     8M   MM    MM      MM  YA.   ,A9   MM    MM    ",
            "JMML. .JMM. `Mbmmd'  YMMMMMb  .JMML.M9mmmP'   `Mbmo .JMML.   `Moo9^Yo.  `Mbmo .JMML. `Ybmd9'  .JMML  JMML. ",
            "                        dP                                                                                 ",
            "                   Ybmmmd'                                                                                 "
            };

            string[] Checker = new string[7]
            {
            "  .g8mmmbgd   7MM                           7MM                        ",
            " .dP'     `M   MM                            MM                        ",
            " dM'       `   MMpMMMb.   .gPmYa   ,p6mbo    MM  ,MP' .gPmYa  `7Mb,od8 ",
            " MM            MM    MM  ,M'   Yb 6M'  OO    MM ;Y   ,M'   Yb   MM' mm ",
            " MM.           MM    MM  8Mmmmmmm 8M         MM;Mm   8Mmmmmmm   MM     ",
            "  Mb.     ,'   MM    MM  YM.    , YM.    ,   MM `Mb. YM.    ,   MM     ",
            "   `fbmmmd'  .JMML  JMML. `Mbmmd'  YMbmd'  .JMML. YA. `Mbmmd' .JMML.   "
            };


            for (int i = 0; i < Vehicle.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine(Vehicle[i]);
            }
            Console.WriteLine(" ");

            for (int i = 0; i < Registration.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                Console.WriteLine(Registration[i]);
            }

            Console.WriteLine(" ");

            for (int i = 0; i < Checker.Length; i++)
            {
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine(Checker[i]);
            }
            Thread.Sleep(5000);
            Console.ResetColor();
            Console.Clear();




            static string ConstruirMenu(int Espacio, string Symbol, int CantidadVecesSymbol)
            {
                string LineaGenerada = "";
                for (int i = 0; i < Espacio; i++)
                {
                    LineaGenerada += " ";
                }
                for (int i = 0; i < CantidadVecesSymbol; i++)
                {
                    LineaGenerada += Symbol;
                }
                return LineaGenerada;
            }




            // Inicializar datos
            InicializarDatos();
            bool continuarMostrandoElMenu = true;

            while (continuarMostrandoElMenu)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(ConstruirMenu(0, "=", 28));
                Console.WriteLine("|   Opciones de Usuario    |");
                Console.WriteLine("|" + ConstruirMenu(26, "=", 0) + "|");
                Console.WriteLine("|" + ConstruirMenu(0, "=", 26) + "|");
                Console.WriteLine("|  1 | 👤  Administrador   |");
                Console.WriteLine("|  2 | 👥  Invitado        |");
                Console.WriteLine("|  3 | ⏪  Salir           |");
                Console.WriteLine("|    |" + ConstruirMenu(21, "=", 0) + "|");
                Console.WriteLine("|" + ConstruirMenu(0, "=", 26) + "|");
                Console.ResetColor();
                Console.WriteLine("Elija el Tipo de Usuario");
                string EleccionM = Console.ReadLine()!;

                if (int.TryParse(EleccionM, out int Opcion))
                {
                    if (Opcion == 1)
                    {
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("| 1. Administrador  | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("| 1. Administrador  | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();

                        bool repetirMenuAdministrador = true;

                        while (repetirMenuAdministrador)
                        {
                            Console.ForegroundColor = ConsoleColor.Blue;
                            Console.WriteLine(ConstruirMenu(0, "=", 33));
                            Console.WriteLine("|   Opciones de Administrador   |"); // 33
                            Console.WriteLine("|  " + ConstruirMenu(26, "=", 0) + "   |");
                            Console.WriteLine("|" + ConstruirMenu(0, "=", 31) + "|");
                            Console.WriteLine("|  1 |  ➕ Agregar Matricula    |");
                            Console.WriteLine("|  2 | 🔎 Consultar Matricula   |");
                            Console.WriteLine("|  3 | ⏪  Volver Atras         |");
                            Console.WriteLine("|    |" + ConstruirMenu(25, "=", 0) + " |");
                            Console.WriteLine("|" + ConstruirMenu(0, "=", 31) + "|");
                            Console.ResetColor();

                            Console.WriteLine("Elija Opcioin Desada");
                            string EleccionO = Console.ReadLine()!;

                            if (int.TryParse(EleccionO, out int opcionEleccion))
                            {
                                if (opcionEleccion == 1) // Codigo para consultar matricula
                                {
                                    AñadirPropietario();

                                }
                                else if (opcionEleccion == 2) // Para poner el codigo de agregar matricula
                                {
                                    BuscarPropietario();
                                }
                                else if (opcionEleccion == 3) // vuelva al menu de usuario
                                {
                                    Console.WriteLine("Volviendo al Menu de Usuario");
                                    Console.Clear();
                                    repetirMenuAdministrador = false;
                                }
                                else // un mensaje y vuelva a mostrar el menu
                                {
                                    Console.WriteLine("Usted a Ingresado un Numero fuera del Rango, Elija Nuevamente");
                                    Console.Clear();
                                }

                            }
                            else // un mensaje y vuelva a mostrar el menu
                            {
                                Console.WriteLine("Usted a Ingresado un Caracter Valido, Elija Nuevamente");
                                Console.Clear();
                            }
                        }

                    }
                    else if (Opcion == 2)
                    {
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("|   2. Invitado     | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("|   2. Invitado     | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();

                        if (Opcion == 2)
                        {


                            VerDatosInvitado();


                        }


                    }
                    else if (Opcion == 3)
                    {
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("|     3. Salir      | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();
                        Console.WriteLine(ConstruirMenu(0, "_", 23));
                        Console.WriteLine("|     3. Salir      | <");
                        Console.WriteLine(ConstruirMenu(0, "-", 23));
                        Thread.Sleep(1000);
                        Console.Clear();
                        continuarMostrandoElMenu = false;
                    }
                    else
                    {
                        Console.WriteLine("Opcion Ingresada Fuera de Rango, vuelva a intentarlo!");
                        Console.Clear();
                    }
                }
                else
                {
                    Console.WriteLine("No ha Ingresado un Caracter valido, vuelva a intentarlo!");
                    Console.Clear();
                }
            }

            static void InicializarDatos()
            {
             matriculas.Add(new KeyValuePair<string, Propietario>("A123456", new Propietario(
    "A123456", "CH12345", "Activo", "Euro 6", "Privado", "Toyota", "Corolla", 2020,
    "Gasolina", 4, "Juan Pérez", "Calle 1, Santo Domingo", "001-234567-89", new DateTime(2025, 12, 31)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("B234567", new Propietario(
    "B234567", "CH23456", "Inactivo", "Euro 5", "Público", "Honda", "Civic", 2018,
    "Gasolina", 4, "Ana Rodríguez", "Calle 2, Santiago", "001-234567-88", new DateTime(2024, 05, 15)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("C345678", new Propietario(
    "C345678", "CH34567", "Activo", "Euro 4", "Privado", "Ford", "Focus", 2021,
    "Gasolina", 4, "Carlos Gómez", "Calle 3, La Vega", "001-234567-87", new DateTime(2026, 07, 20)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("D456789", new Propietario(
    "D456789", "CH45678", "Activo", "Euro 6", "Público", "Chevrolet", "Aveo", 2019,
    "Gasolina", 4, "Marta López", "Calle 4, Puerto Plata", "001-234567-86", new DateTime(2027, 10, 10)
)));

matriculas.Add(new KeyValuePair<string, Propietario>("E567890", new Propietario(
    "E567890", "CH56789", "Activo", "Euro 5", "Privado", "Nissan", "Altima", 2022,
    "Gasolina", 4, "Luis Fernández", "Calle 5, Punta Cana", "001-234567-85", new DateTime(2028, 03, 25)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("F678901", new Propietario(
    "F678901", "CH67890", "Inactivo", "Euro 6", "Público", "Hyundai", "Elantra", 2020,
    "Gasolina", 4, "Paola Martínez", "Calle 6, San Pedro", "001-234567-84", new DateTime(2026, 11, 30)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("G789012", new Propietario(
    "G789012", "CH78901", "Activo", "Euro 5", "Privado", "Mazda", "3", 2019,
    "Gasolina", 4, "Roberto Díaz", "Calle 7, Higüey", "001-234567-83", new DateTime(2027, 09, 18)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("H890123", new Propietario(
    "H890123", "CH89012", "Inactivo", "Euro 4", "Público", "Volkswagen", "Golf", 2017,
    "Gasolina", 4, "Laura González", "Calle 8, Bayaguana", "001-234567-82", new DateTime(2024, 01, 20)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("I901234", new Propietario(
    "I901234", "CH90123", "Activo", "Euro 6", "Privado", "BMW", "X5", 2021,
    "Gasolina", 4, "Francisco Ruiz", "Calle 9, Bonao", "001-234567-81", new DateTime(2027, 02, 14)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("J012345", new Propietario(
    "J012345", "CH01234", "Activo", "Euro 5", "Público", "Audi", "A3", 2019,
    "Gasolina", 4, "Pedro Sánchez", "Calle 10, La Romana", "001-234567-80", new DateTime(2026, 12, 05)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("K123456", new Propietario(
    "K123456", "CH12345", "Inactivo", "Euro 6", "Privado", "Kia", "Sportage", 2022,
    "Gasolina", 4, "María Pérez", "Calle 11, Moca", "001-234567-79", new DateTime(2028, 04, 11)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("L234567", new Propietario(
    "L234567", "CH23456", "Activo", "Euro 4", "Público", "Chevrolet", "Spark", 2020,
    "Gasolina", 4, "Antonio López", "Calle 12, Azua", "001-234567-78", new DateTime(2026, 08, 10)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("M345678", new Propietario(
    "M345678", "CH34567", "Inactivo", "Euro 5", "Privado", "Ford", "Fiesta", 2021,
    "Gasolina", 4, "Liliana Pérez", "Calle 13, San Cristóbal", "001-234567-77", new DateTime(2027, 03, 15)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("N456789", new Propietario(
    "N456789", "CH45678", "Activo", "Euro 6", "Público", "Toyota", "Yaris", 2020,
    "Gasolina", 4, "José Rodríguez", "Calle 14, Santiago Rodríguez", "001-234567-76", new DateTime(2026, 11, 20)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("O567890", new Propietario(
    "O567890", "CH56789", "Activo", "Euro 6", "Privado", "Honda", "CR-V", 2018,
    "Gasolina", 4, "Elena Martínez", "Calle 15, Hato Mayor", "001-234567-75", new DateTime(2027, 06, 13)
)));


matriculas.Add(new KeyValuePair<string, Propietario>("P678901", new Propietario(
    "P678901", "CH67890", "Activo", "Euro 6", "Privado", "Mazda", "CX-5", 2021,
    "Gasolina", 4, "Ricardo Díaz", "Calle 16, Villa Altagracia", "001-234567-74", new DateTime(2026, 09, 10)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("Q789012", new Propietario(
    "Q789012", "CH78901", "Inactivo", "Euro 5", "Público", "Hyundai", "Santa Fe", 2022,
    "Gasolina", 4, "Marisol Castro", "Calle 17, Dajabón", "001-234567-73", new DateTime(2027, 01, 30)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("R890123", new Propietario(
    "R890123", "CH89012", "Activo", "Euro 4", "Privado", "Volkswagen", "Jetta", 2020,
    "Gasolina", 4, "Víctor Gómez", "Calle 18, El Seibo", "001-234567-72", new DateTime(2025, 11, 25)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("S901234", new Propietario(
    "S901234", "CH90123", "Inactivo", "Euro 6", "Público", "BMW", "Serie 3", 2021,
    "Gasolina", 4, "Pedro Sánchez", "Calle 19, Cotuí", "001-234567-71", new DateTime(2026, 07, 12)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("T012345", new Propietario(
    "T012345", "CH01234", "Activo", "Euro 5", "Privado", "Nissan", "X-Trail", 2020,
    "Gasolina", 4, "Elena Pérez", "Calle 20, Bonao", "001-234567-70", new DateTime(2027, 09, 15)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("U123456", new Propietario(
    "U123456", "CH12345", "Activo", "Euro 4", "Público", "Chevrolet", "Traverse", 2018,
    "Gasolina", 4, "Carlos Rodríguez", "Calle 21, Jarabacoa", "001-234567-69", new DateTime(2026, 04, 01)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("V234567", new Propietario(
    "V234567", "CH23456", "Inactivo", "Euro 6", "Privado", "Honda", "Pilot", 2019,
    "Gasolina", 4, "Laura González", "Calle 22, San Juan", "001-234567-68", new DateTime(2024, 02, 22)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("W345678", new Propietario(
    "W345678", "CH34567", "Activo", "Euro 5", "Público", "Mazda", "MX-5", 2021,
    "Gasolina", 4, "Jorge Martínez", "Calle 23, San Cristóbal", "001-234567-67", new DateTime(2027, 11, 15)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("X456789", new Propietario(
    "X456789", "CH45678", "Inactivo", "Euro 6", "Privado", "Toyota", "Land Cruiser", 2022,
    "Gasolina", 4, "Sofia Rodríguez", "Calle 24, La Vega", "001-234567-66", new DateTime(2025, 12, 10)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("Y567890", new Propietario(
    "Y567890", "CH56789", "Activo", "Euro 4", "Público", "Chevrolet", "Tahoe", 2020,
    "Gasolina", 4, "Juan Fernández", "Calle 25, Higüey", "001-234567-65", new DateTime(2026, 10, 07)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("Z678901", new Propietario(
    "Z678901", "CH67890", "Activo", "Euro 5", "Privado", "Ford", "Explorer", 2021,
    "Gasolina", 4, "Miguel Jiménez", "Calle 26, San Pedro", "001-234567-64", new DateTime(2027, 01, 10)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("A789012", new Propietario(
    "A789012", "CH78901", "Inactivo", "Euro 6", "Público", "Honda", "Odyssey", 2022,
    "Gasolina", 4, "Martina Rodríguez", "Calle 27, Moca", "001-234567-63", new DateTime(2026, 05, 14)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("B890123", new Propietario(
    "B890123", "CH89012", "Activo", "Euro 4", "Privado", "BMW", "X6", 2020,
    "Gasolina", 4, "Nicolás Pérez", "Calle 28, Puerto Plata", "001-234567-62", new DateTime(2027, 12, 09)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("C901234", new Propietario(
    "C901234", "CH90123", "Activo", "Euro 6", "Público", "Mazda", "6", 2021,
    "Gasolina", 4, "Daniela Martínez", "Calle 29, Santo Domingo", "001-234567-61", new DateTime(2026, 03, 22)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("D012345", new Propietario(
    "D012345", "CH01234", "Inactivo", "Euro 5", "Privado", "Kia", "Seltos", 2020,
    "Gasolina", 4, "Ricardo López", "Calle 30, Santiago", "001-234567-60", new DateTime(2024, 06, 19)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("E123456", new Propietario(
    "E123456", "CH12345", "Activo", "Euro 4", "Público", "Ford", "F-150", 2019,
    "Gasolina", 4, "Carlos López", "Calle 31, Baní", "001-234567-59", new DateTime(2025, 08, 05)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("F234567", new Propietario(
    "F234567", "CH23456", "Inactivo", "Euro 5", "Privado", "Chevrolet", "Camaro", 2022,
    "Gasolina", 4, "Adriana Fernández", "Calle 32, San Cristóbal", "001-234567-58", new DateTime(2027, 02, 25)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("G345678", new Propietario(
    "G345678", "CH34567", "Activo", "Euro 6", "Público", "Audi", "Q7", 2021,
    "Gasolina", 4, "Jorge Martínez", "Calle 33, Higüey", "001-234567-57", new DateTime(2026, 10, 12)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("H456789", new Propietario(
    "H456789", "CH45678", "Activo", "Euro 4", "Privado", "BMW", "X3", 2018,
    "Gasolina", 4, "Carmen Sánchez", "Calle 34, Bayaguana", "001-234567-56", new DateTime(2024, 09, 20)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("I567890", new Propietario(
    "I567890", "CH56789", "Inactivo", "Euro 5", "Público", "Toyota", "Prius", 2020,
    "Gasolina", 4, "Carlos Gómez", "Calle 35, Santiago", "001-234567-55", new DateTime(2027, 01, 18)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("J678901", new Propietario(
    "J678901", "CH67890", "Activo", "Euro 6", "Privado", "Honda", "Accord", 2021,
    "Gasolina", 4, "María Rodríguez", "Calle 36, Moca", "001-234567-54", new DateTime(2026, 08, 25)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("K789012", new Propietario(
    "K789012", "CH78901", "Activo", "Euro 4", "Público", "Ford", "Escape", 2020,
    "Gasolina", 4, "Alejandro Torres", "Calle 37, San Pedro", "001-234567-53", new DateTime(2025, 07, 01)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("L890123", new Propietario(
    "L890123", "CH89012", "Inactivo", "Euro 5", "Privado", "Chevrolet", "Spark", 2022,
    "Gasolina", 4, "Lourdes Herrera", "Calle 38, Jarabacoa", "001-234567-52", new DateTime(2027, 03, 19)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("M901234", new Propietario(
    "M901234", "CH90123", "Activo", "Euro 6", "Público", "Honda", "CR-V", 2021,
    "Gasolina", 4, "Luis Rodríguez", "Calle 39, Bonao", "001-234567-51", new DateTime(2026, 12, 05)
)));
matriculas.Add(new KeyValuePair<string, Propietario>("N012345", new Propietario(
    "N012345", "CH01234", "Activo", "Euro 4", "Privado", "Hyundai", "Tucson", 2020,
    "Gasolina", 4, "Juan Carlos Pérez", "Calle 40, Cotuí", "001-234567-50", new DateTime(2024, 11, 16)
)));



            }

            static void BuscarPropietario()
            {
                Console.Write("Introduce la matrícula a buscar: ");
                string matriculaBuscada = Console.ReadLine()!.ToUpper();

                bool encontrada = false;
                foreach (var item in matriculas)
                {
                    if (item.Key == matriculaBuscada)
                    {
                        Console.WriteLine("\nInformación del propietario:");
                        Console.WriteLine(item.Value);
                        encontrada = true;
                        break;
                    }
                }

                if (!encontrada)
                {
                    Console.WriteLine("Matrícula no encontrada.");
                }
            }

            static void AñadirPropietario()
            {
                Console.WriteLine("\nIntroduce los datos del nuevo propietario:");

                Console.Write("Matrícula: ");
                string matricula = Console.ReadLine()!.ToUpper();

                Console.Write("Chasis: ");
                string chasis = Console.ReadLine()!;

                Console.Write("Estatus del Vehículo: ");
                string estatus = Console.ReadLine()!;

                Console.Write("Tipo de Emisión: ");
                string tipoEmision = Console.ReadLine()!;

                Console.Write("Tipo de Vehículo (Privado/Público): ");
                string tipoVehiculo = Console.ReadLine()!;

                Console.Write("Marca: ");
                string marca = Console.ReadLine()!;

                Console.Write("Modelo: ");
                string modelo = Console.ReadLine()!;

                Console.Write("Año de Fabricación: ");
                int anoFabricacion = int.Parse(Console.ReadLine()!);

                Console.Write("Fuerza Motriz: ");
                string fuerzaMotriz = Console.ReadLine()!;

                Console.Write("Cilindros: ");
                int cilindros = int.Parse(Console.ReadLine()!);

                Console.Write("Propietario o Razón Social: ");
                string nombre = Console.ReadLine()!;

                Console.Write("Dirección: ");
                string direccion = Console.ReadLine()!;

                Console.Write("Cédula o Pasaporte: ");
                string cedula = Console.ReadLine()!;

                Console.Write("Fecha de Expiración (yyyy-MM-dd): ");
                DateTime fechaExpiracion = DateTime.Parse(Console.ReadLine()!);

                var nuevoPropietario = new Propietario(matricula, chasis, estatus, tipoEmision, tipoVehiculo, marca, modelo, anoFabricacion,
                                                       fuerzaMotriz, cilindros, nombre, direccion, cedula, fechaExpiracion);

                matriculas.Add(new KeyValuePair<string, Propietario>(matricula, nuevoPropietario));
                GuardarEnArchivo(nuevoPropietario);
                Console.WriteLine("\nPropietario añadido y guardado exitosamente.");
            }

            static void GuardarEnArchivo(Propietario propietario)
            {
                string rutaArchivo = "Propietarios.txt";
                using (StreamWriter sw = new StreamWriter(rutaArchivo, true))
                {
                    sw.WriteLine(propietario.ToString());
                    sw.WriteLine("=====================================");
                }
            }
        }
    }

    static void VerDatosInvitado()
    {
        Console.Write("Introduce la matrícula del vehículo que deseas ver: ");
        string matriculaBuscada = Console.ReadLine()!.ToUpper();

        bool encontrada = false;
        foreach (var item in matriculas)
        {
            if (item.Key == matriculaBuscada)
            {
                // Muestra solo información limitada para el invitado
                Console.WriteLine("\nInformación del vehículo para invitado:");
                Console.WriteLine($"Placa: {item.Value.RegistroPlaca}");
                Console.WriteLine($"Tipo de Vehículo: {item.Value.TipoVehiculo}");
                Console.WriteLine($"Marca: {item.Value.Marca}");
                Console.WriteLine($"Modelo: {item.Value.Modelo}");
                Console.WriteLine($"Año de Fabricación: {item.Value.AnosDeFabricacion}");
                Console.WriteLine($"Fuerza Motriz: {item.Value.FuerzaMotriz}");
                Console.WriteLine($"Cilindrada: {item.Value.Cilindros} cilindros");
                encontrada = true;
                break;
            }
        }

        if (!encontrada)
        {
            Console.WriteLine("Matrícula no encontrada.");
        }
    }
}