/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cadenas.de.suma1;

/**
 *
 * @author EJMA
 * 
 * Realizar un programa que imprima la sumatoria de los números del 1 al 50 utilizando ciclos "do while".
 */
public class CadenasDeSuma1 {
    public static void main(String[] args) {
        // TODO code application logic here
        
        /*
        se crean dos variables con valores predefinidos
        */
        int numero1 = 1; 
        int i = 0;
        
        /*
        creamos un bucle para que se ejecute mientras cumpla con la condicion
        */
        do {            
            
            i+= numero1; // sumatoria de los numeros 
            numero1++; // incremento de los numeros 
            
        } while (numero1 <= 50); // condicion que le dimos al bucle
        System.out.println("La sumatoria de los numeros del 1 al 50 es: " + i);
    }
    
}
