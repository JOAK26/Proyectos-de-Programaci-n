package ejercicio1_nombrecorreo;
/**
 *
 * @author EJMA
 */
public class Ejercicio1_NombreCorreo {
    
    /**
     * Realizar un programa que imprima por pantalla su nombre y correo electrónico.
     * /
     *
     * @param args 
     */
    public static void main(String[] args) {
        // TODO code application logic here
        /**
         * En esta parte se imprimen los datos del usuario ingresado
         */
        System.out.println("Name: Esteban Josue Mata Acosta");
        System.out.println("Email: matajosue484@gmail.com");
        
    }
    
}
