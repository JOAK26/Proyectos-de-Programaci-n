/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package incremento.pkg1.al.pkg100;

/**
 *
 * @author EJMA
 * Realizar un programa que imprima los números impares del 1 al 100 utilizando ciclos "for".
 */
public class Incremento1Al100 {
    public static void main(String[] args) {
        
        /*
        *En esta seccion del codigo creamos un ciclo for donde se realizara un incremento solo mostrando los numeros impares/
        */
       
        for (int i = 0; i <= 100; i ++) {
                
            if (i % 2 != 0)
         
            System.out.println("Incremento de numeros: " + i);
            
        }         
    }
}
