﻿using System;

class Program
{

    public static void Main(string[] args)
    {



        int num = 0;
        int contador = 0;
        int resultado = 0;
       


        while (num <= 100)
        {

            contador = num++;
            resultado = contador;


            if (resultado % 2 != 0)
            {
                Console.WriteLine("Estos son los numeros impares");
                Console.WriteLine(resultado);


            }

        }
        Console.WriteLine("Fin");
        Console.ReadLine();
    }

}