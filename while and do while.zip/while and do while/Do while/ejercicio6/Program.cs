﻿using System;

class Program
{
    public static void Main(string[] args)
    {


        Console.WriteLine("Ingrese un numero");
        int num = Convert.ToInt32(Console.ReadLine());
        int multi;

        multi = num * 5;
        if (multi % 2 == 0)

        {
            int contador = num;
            do{
                Console.WriteLine(contador);
                contador++;


            }while (contador <= multi);
        }
        else
        {
            int contador = multi;
            do
            {
                Console.WriteLine(contador);
                contador--;

            }while (contador >= num);
        }
    }
}


