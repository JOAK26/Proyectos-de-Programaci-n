﻿using System;

class Program
{

    public static void Main(string[] args)
    {



        int num = 0;
        int contador = 0;
        int resultado = 0;
       


        do
        {

            contador = num++;
            resultado = contador;


            if (resultado % 2 != 0)
            {
                Console.WriteLine("Estos son los numeros impares");
                Console.WriteLine(resultado);


            }

        }while (num <= 100);
        
        Console.WriteLine("Fin");
        Console.ReadLine();
    }

}