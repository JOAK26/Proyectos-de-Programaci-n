﻿using System; 

class Program {
    public static void Main (string [] args){

        int num = 0 ; 
        

        

        do{
        Console.WriteLine("Este es el resultado " + num);
           num += 5 ;   // Equivalente a numero = numero + 5;
        }while(num <= 1000);
        

        Console.ReadLine();
    }
}