﻿using System;

class Program{
 
 public static void Main (string[]args){



int num  = 500;
int contador = 0 ;
int resultado = 0 ;


do
{

contador = num--;
resultado = contador ;

Console.WriteLine(resultado);

}while ( num >= 1);

Console.WriteLine("Fin");
Console.ReadLine();




 }

}