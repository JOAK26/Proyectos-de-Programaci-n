﻿//4. PROGRAMA QUE MUESTRE EN PANTALLA LOS NUMEROS DEL 0 AL 1000, INCREMENTANDO DE 5 EN 5

using System; 

class Program {
    public static void Main (string [] args){

        int num = 0 ; 
        

        

        while(num <= 1000){
        Console.WriteLine("Este es el resultado" + num);
           num += 5 ;   // Equivalente a numero = numero + 5;
        }
        

        Console.ReadLine();
    }
}