﻿//7. PROGRAMA QUE PIDA AL USUARIO DOS NUMERO. SI EL 1ER NUMERO ES MAYOR QUE EL SEGUNDO, MOSTRARA LA SECUENCIA DESCENDENTE DESDE EL PRIMER NUMERO HASTA EL SEGUNDO, EN CASO CONTRARIO MOSTRAR LA SECUENCIA ASCENDENTE.
using System;

class Program
{
    public static void Main(string[] args)
    {


        Console.WriteLine("Ingrese el primer número:");
        int num1 = Convert.ToInt32(Console.ReadLine());   

        Console.WriteLine("Ingrese el segundo número:");
        int num2 = Convert.ToInt32(Console.ReadLine());   



        if (num1 > num2)

        {
            int contador = num1;
            while (contador >= num2)
            {
                Console.WriteLine(contador);
                contador--;
            }
        }
        else
        {
            int contador = num1;
            while (contador <= num2)
            {
                Console.WriteLine(contador);
                contador ++ ;

            }
        }
    }
}


