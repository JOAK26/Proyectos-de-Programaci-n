﻿using System;

class Program{
 
 public static void Main (string[]args){



int num  = 0;
int contador = 0 ;
int resultado = 0 ;


while ( num <= 500)
{

contador = num++;
resultado = contador ;

Console.WriteLine(resultado);

}

Console.WriteLine("Fin");
Console.ReadLine();




 }

}