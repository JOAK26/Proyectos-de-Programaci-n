﻿//6. PROGRAMA QUE PIDA AL USUARIO UN NUMERO. EL NUMERO RECIBIDO LO MULTIPLICARA POR 5. SI EL RESU24R, MOSTRARA EN PANTALLA LA SECUENCIA ASCENDENTE DESDE EL NUMERO RECIBIDO HASTA EL RESULTADO DE LA MULTIPLICACION. EN CASO CONTRARIO, MOSTRARA LA SECUENCIA DESCENDENTE DESDE EL RESULTADO DE LA MULTIPLICACION HASTA EL NUMERO INGRESADO.

using System;

class Program
{
    public static void Main(string[] args)
    {


        Console.WriteLine("Ingrese un numero");
        int num = Convert.ToInt32(Console.ReadLine());
        int multi;

        multi = num * 5;
        if (multi % 2 == 0)

        {
            int contador = num;
            while (contador <= multi)
            {
                Console.WriteLine(contador);
                contador++;


            }
        }
        else
        {
            int contador = multi;
            while (contador >= num)
            {
                Console.WriteLine(contador);
                contador--;

            }
        }
    }
}












