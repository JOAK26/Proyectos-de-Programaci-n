﻿//5. PROGRAMA QUE PIDA AL USUARIO UN NUMERO, Y MUESTR EN PANTALLA LA SECUENCIA DESCENDENTE DESDE EL NUMERO INGRESADO HASTA 0

using System; 

class Program {
    public static void Main (string [] args){


        Console.WriteLine("Ingrese un numero");
        int num = Convert.ToInt32(Console.ReadLine()); 
        int contador = 0 ;
        

        

        while(num >= 0){

           
           contador = num -- ;

 Console.WriteLine("Este es el resultado"  +  contador);
        }
        

        Console.ReadLine();
    }
}