﻿using System; 

class Program{
 
 public static void Main ( string [] args){

const string e = "e";
const string i = "i";
const string f = "f";


Console.WriteLine("[E] Español  [I] Inglés  [F] Francés");
Console.Write("Seleccione una opción: ");
string letra = Console.ReadLine()!;
 
switch (letra){

    case e : Console.WriteLine("El conocimiento es poder."); break;
    case i : Console.WriteLine("Knowledge is power"); break;
    case f : Console.WriteLine("Le savoir est le pouvoir."); break;
}

Console.ReadLine();



 }

}