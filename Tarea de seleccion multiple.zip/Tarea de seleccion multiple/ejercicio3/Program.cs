﻿using System ;

class Program {
    public static void Main (string [ ] args){

        Console.WriteLine("Escriba un numero del 1 al 7");
        int numero = Convert.ToInt32 (Console.ReadLine());
        Console.Write($"Su dia seleccionado fue ");
        switch (numero){

            case 1 : Console.WriteLine("Domingo");break;
            case 2 : Console.WriteLine("Lunes");break;
            case 3 : Console.WriteLine("Martes");break;
            case 4 : Console.WriteLine("Miercoles");break;
            case 5 : Console.WriteLine("Jueves");break;
            case 6 : Console.WriteLine("Viernes");break;
            case 7 : Console.WriteLine("Sabado");break;

            default : Console.WriteLine("Se ingreso un numero no valido"); break;


        }

   
        Console.ReadLine();

    }
}