/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package numeros.pares.pkg2.al.pkg100;

/**
 *
 * @author EJMA
 */
public class NumerosPares2Al100 {

    public static void main(String[] args) {
        
        /*
         * se ingreso una variable numero con el valor cero para incrementarla en le ciclo ya que no  tiene una variable predefinida como el for.
         */
        int numero1 = 0;
        
        /*
         * se repetira el codigo hasta llegar a 100 y sacar cada digito par o que se pueda dividir y se mostrara en pantalla 
         */
        while( numero1 < 100){
        
        numero1++;

        if(numero1 % 2 == 0) {
        
            System.out.println("estos son los numeros pares: " + numero1 );
        }
        }               
    }   
}
