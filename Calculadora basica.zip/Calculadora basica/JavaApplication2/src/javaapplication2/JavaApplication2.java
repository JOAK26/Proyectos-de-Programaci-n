/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication2;

import java.util.Scanner;
/**
 *
 * @author EJMA
 */

/**
 * Realizar un programa que incluya las 4 operaciones matemáticas básicas (Suma, Resta, Multiplicación y División)
 */

public class JavaApplication2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        /*
        *En esta parte del codigo se encarga de solicitarle el usuario dos numeros pera almacenarlos.
        */
        System.out.println("Introdusca un numero");
        int numero1 = s.nextInt();
        
        System.out.println("Ingrese un segundo numero");
        int numero2 = s.nextInt();
        /*
        *Aqui el programa realizara sus respectivos calculos con los numeros ingresadir por el usuario.
        */
        int suma = numero1 + numero2; 
        int resta = numero1 - numero2;
        int multi = numero1 * numero2;
        int divi = numero1 / numero2;
         /*
        *En esta parte se nmostraran los datos en pantalla de los resultados. 
        */
        System.out.println("Estos son los valores finales de cada operacion...");
        System.out.println("Suma: " + suma + " resta: " + resta + " multiplicacion: " + multi + " Divicion: " + divi);
        
    }
    
}
