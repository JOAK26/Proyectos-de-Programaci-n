﻿using System;
using System.Collections.Generic;

public class Propietario
{
    public string RegistroPlaca { get; set; } // get: Se utiliza para obtener (leer)
    public string Chasis { get; set; } //set: Se utiliza para establecer (escribir) 
    public string EstatusVehiculo { get; set; }
    public string TipoEmision { get; set; }
    public string TipoVehiculo { get; set; }  // Privado o Público
    public string Marca { get; set; }
    public string Modelo { get; set; }
    public int AnosDeFabricacion { get; set; }
    public string FuerzaMotriz { get; set; }
    public int Cilindros { get; set; }
    public string NombreRazonSocial { get; set; }
    public string Direccion { get; set; }
    public string CedulaOPasaporte { get; set; }
    public DateTime FechaExpiracion { get; set; }

    // Constructor
    public Propietario(string registroPlaca, string chasis, string estatusVehiculo, string tipoEmision, string tipoVehiculo,
                    string marca, string modelo, int anosDeFabricacion, string fuerzaMotriz, int cilindros,
                    string nombreRazonSocial, string direccion, string cedulaOPasaporte, DateTime fechaExpiracion)
    {
        RegistroPlaca = registroPlaca;
        Chasis = chasis;
        EstatusVehiculo = estatusVehiculo;
        TipoEmision = tipoEmision;
        TipoVehiculo = tipoVehiculo;
        Marca = marca;
        Modelo = modelo;
        AnosDeFabricacion = anosDeFabricacion;
        FuerzaMotriz = fuerzaMotriz;
        Cilindros = cilindros;
        NombreRazonSocial = nombreRazonSocial;
        Direccion = direccion;
        CedulaOPasaporte = cedulaOPasaporte;
        FechaExpiracion = fechaExpiracion;
    }


    public override string ToString() // el override se utiliza para sobrescribir un metodo esto quiere decir que es una derivada que permite cambiar el comportamiento de una base 
    {
        return $"Placa: {RegistroPlaca}\nChasis: {Chasis}\nEstatus del Vehículo: {EstatusVehiculo}\nTipo de Emisión: {TipoEmision}\nTipo de Vehículo: {TipoVehiculo}\n" +
               $"Marca: {Marca}\nModelo: {Modelo}\nAño de Fabricación: {AnosDeFabricacion}\nFuerza Motriz: {FuerzaMotriz}\nCilindrada: {Cilindros} cilindros\n" +
               $"Propietario o Razón Social: {NombreRazonSocial}\nDirección: {Direccion}\nCédula o Pasaporte: {CedulaOPasaporte}\nFecha de Expiración: {FechaExpiracion.ToShortDateString()}";
    }
}

class Program
{
    static void Main()
    {
        // Arreglo con información de vehículos y propietarios // KeyValuePair es como una primary key que almacena un valor en espesifico en este casi la placa 
        var matriculas = new KeyValuePair<string, Propietario>[]
        {
             new KeyValuePair<string, Propietario>("A123456", new Propietario(
                "A123456", "CH12345", "Activo", "Euro 6", "Privado", "Toyota", "Corolla", 2020,
                "Gasolina", 4, "Juan Pérez", "Calle 1, Santo Domingo", "001-234567-89", new DateTime(2025, 12, 31)
            )),
            new KeyValuePair<string, Propietario>("B234567", new Propietario(
                "B234567", "CH23456", "Inactivo", "Euro 5", "Público", "Honda", "Civic", 2018,
                "Gasolina", 4, "Ana Rodríguez", "Calle 2, Santiago", "001-234567-88", new DateTime(2024, 05, 15)
            )),
            new KeyValuePair<string, Propietario>("C345678", new Propietario(
                "C345678", "CH34567", "Activo", "Euro 4", "Privado", "Ford", "Focus", 2021,
                "Gasolina", 4, "Carlos Gómez", "Calle 3, La Vega", "001-234567-87", new DateTime(2026, 07, 20)
            )),
            new KeyValuePair<string, Propietario>("D456789", new Propietario(
                "D456789", "CH45678", "Activo", "Euro 6", "Público", "Chevrolet", "Aveo", 2019,
                "Gasolina", 4, "Marta López", "Calle 4, Puerto Plata", "001-234567-86", new DateTime(2027, 10, 10)
            )),
            // Agregar más vehículos con propietarios
            new KeyValuePair<string, Propietario>("E567890", new Propietario(
                "E567890", "CH56789", "Activo", "Euro 6", "Privado", "Nissan", "Altima", 2020,
                "Gasolina", 4, "Luis Martínez", "Calle 5, San Juan", "001-234567-85", new DateTime(2024, 08, 01)
            )),
            new KeyValuePair<string, Propietario>("F678901", new Propietario(
                "F678901", "CH67890", "Inactivo", "Euro 5", "Público", "Hyundai", "Elantra", 2017,
                "Gasolina", 4, "Pedro Hernández", "Calle 6, Moca", "001-234567-84", new DateTime(2023, 03, 10)
            )),
            new KeyValuePair<string, Propietario>("G789012", new Propietario(
                "G789012", "CH78901", "Activo", "Euro 5", "Privado", "Mazda", "CX-5", 2021,
                "Gasolina", 4, "Laura Martínez", "Calle 7, Higüey", "001-234567-83", new DateTime(2026, 01, 01)
            )),
            new KeyValuePair<string, Propietario>("H890123", new Propietario(
                "H890123", "CH89012", "Activo", "Euro 6", "Público", "Kia", "Seltos", 2019,
                "Gasolina", 4, "Julio Ramírez", "Calle 8, La Romana", "001-234567-82", new DateTime(2025, 11, 22)
            )),
            new KeyValuePair<string, Propietario>("I901234", new Propietario(
                "I901234", "CH90123", "Activo", "Euro 6", "Privado", "Ford", "Mustang", 2022,
                "Gasolina", 6, "Ricardo Pérez", "Calle 9, Puerto Plata", "001-234567-81", new DateTime(2028, 12, 31)
            )),
            new KeyValuePair<string, Propietario>("J012345", new Propietario(
                "J012345", "CH01234", "Inactivo", "Euro 5", "Público", "Toyota", "Hilux", 2018,
                "Diésel", 4, "Marta Rodríguez", "Calle 10, Santiago", "001-234567-80", new DateTime(2023, 05, 15)
            )),
            // Continuar agregando los 17 restantes (puedes copiar el formato anterior y modificar los valores)
            new KeyValuePair<string, Propietario>("K123456", new Propietario(
                "K123456", "CH12367", "Activo", "Euro 6", "Privado", "BMW", "X5", 2023,
                "Gasolina", 6, "Felipe García", "Calle 11, Santo Domingo", "001-234567-79", new DateTime(2029, 06, 30)
            )),
        };

        // Buscar matrícula
        Console.WriteLine("Introduce la matrícula:");
        string matriculaBuscada = Console.ReadLine()!.ToUpper();

        bool encontrada = false;
        foreach (var item in matriculas)
        {
            if (item.Key == matriculaBuscada)
            {
                Console.WriteLine("\nInformación del propietario:");
                Console.WriteLine(item.Value);
                encontrada = true;
                break;
            }
        }

        if (!encontrada)
        {
            Console.WriteLine("Matrícula no encontrada.");
        }
    }
}
