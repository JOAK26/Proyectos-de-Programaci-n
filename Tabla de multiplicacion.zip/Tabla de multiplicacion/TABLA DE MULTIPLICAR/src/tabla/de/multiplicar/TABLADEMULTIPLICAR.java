/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tabla.de.multiplicar;

import java.util.Scanner;

/**
 *
 * @author EJMA
 */
public class TABLADEMULTIPLICAR {

    
    public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         
         /*
         Ingresar el primer dijito que es el que dira cual tabla desa multiplicar
         */
         System.out.println("Ingrese el numero de la tabla que quiere que se imprima");
         int numero1 = s.nextInt();
         /*
         Y este se usara para medir el alcance de la tabla o hasta donde queremos que llegue 
         */
          System.out.println("Ingrese el numero de la tabla que quiere que se imprima");
         int numero2 = s.nextInt();
         
         
         for (int i = 0; i <= numero2; i++) { // bucle donde se muestra la condicion de nuestra tabla
             
             int multi; // variable de multiplicacion
             
             multi = numero1 * i; 
             
             System.out.println("Su tabla de multiplicacion es: " + numero1 +  " * " + i + " = " + multi );
            
        }
         
        
        
    }
    
}
