﻿//Escriba un programa que pregunte cuántos números se van a introducir, pida esos números y muestre cuántos números negativos ha introducido.

using System;

class Program
{

    public static void Main(string[] args)
    {


        Console.WriteLine("Cuantos numeros desea introducir ?");
        int cantidad = int.Parse(Console.ReadLine()!);


        int contador = 0;
     

        for (int i = 0; i < cantidad; i++)
        {

            Console.WriteLine("Introdusca el numero" + i);
            int numero = int.Parse(Console.ReadLine()!);


            if (numero < 0)
            {

                contador++;

            }


        }
        Console.Clear();
        Console.WriteLine("Se mostraran los contadores negarivos");
        Thread.Sleep(2000);
        Console.WriteLine($"A introducido  {contador}, numeros negativos");



    }

}