﻿//Escriba un programa que solicite dos numeros. Debe mostrar la secuencia descendente desde el numero mas grande hasta el numero menor

using System;

class Program
{

    public static void Main(string[] args)
    {

        Console.WriteLine("Ingrese su primer numero");
        int numero1 = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese su segundo numero");
        int numero2 = Convert.ToInt32(Console.ReadLine());




        if (numero1 > numero2)
        {

            for (int i = numero1; i >= numero2; i--)
            {
                Console.WriteLine();
                Console.WriteLine(i);



            }

        }
        else if (numero1 < numero2)
        {


            for (int i = numero2; i >= numero1; i--)
            {
                Console.WriteLine();
                Console.WriteLine(i);


            }
        }
        Console.Read();
    }
}