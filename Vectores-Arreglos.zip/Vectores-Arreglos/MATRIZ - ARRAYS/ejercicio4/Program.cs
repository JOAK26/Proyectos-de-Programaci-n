﻿//PROGRAMA QUE LEA 5 NÚMEROS POR TECLADO. DEBE COPIAR LOS VALORES EN UN SEGUNDO ARREGLO, SIGUIENDO ESTE REQUERIMIENTO:

//SI EL NUMERO DE TURNO DEL PRIMER ARREGLO ES PAR, COPIARLO AL SEGUNDO ARREGLO MULTIPLICADO POR 10
//EN CASO CONTRARIO COPIARLO AL SEGUNDO ARREGLO TAL COMO ESTA.

using System ;

class Program {
    public static void Main (){

        System.Console.WriteLine("Ingrese 5 numeros");

        int[] ALMACEN4 = new int [5];

        for (int i = 0; i < ALMACEN4.Length; i++){
           ALMACEN4[i] = Convert.ToInt32 (Console.ReadLine());
        }
        
       int[] ALMACEN5 = new int [5];
       
     

        for (int i = 0; i < ALMACEN5.Length; i++){

            if (ALMACEN4[i] % 2 == 0){
              ALMACEN5[i] = ALMACEN4[i] * 10;
            System.Console.WriteLine(ALMACEN5[i]);
            }else{
           ALMACEN5[i] = ALMACEN4[i];
                System.Console.WriteLine(ALMACEN5[i]);
            }

        
        }
    	Console.ReadLine();

    }
}