﻿//PROGRAMA QUE LE PIDA AL USUARIO 5 NÚMEROS Y LOS ALMACENE EN UN ARREGLO. CUANDO EL USUARIO TERMINE DE INGRESARLOS  DEBE MOSTRAR LA SUMATORIA DE ESOS NÚMEROS.

using System;
using System.Globalization;

class Program
{

    public static void Main()
    {

        Console.WriteLine("Introdusca cinco numeros");
    

        int[] ALMACENE = new int[5];

        int suma = 0;
        for (int i = 0; i < ALMACENE.Length; i++)
        {
            ALMACENE[i] =Convert.ToInt32( Console.ReadLine());
        }
         foreach (int num in ALMACENE)
         {
            Console.WriteLine(num);

              suma += num;

         }
        Console.WriteLine(suma);

      





    }
}