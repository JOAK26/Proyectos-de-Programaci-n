﻿//PROGRAMA QUE LEA 10 NÚMEROS ENTEROS INGRESADOS POR EL USUARIO Y LOS INSERTE EN UN ARREGLO. A CONTINUACIÓN, EL PROGRAMA DEBE CONTAR Y CLASIFICAR CUÁNTOS NÚMEROS PARES Y CUÁNTOS NÚMEROS IMPARES HAY DENTRO DEL ARREGLO, Y MOSTRAR ESOS RESULTADOS.

using System;
using System.ComponentModel.DataAnnotations;

class Program
{
    public static void Main()
    {

        System.Console.WriteLine("Escriba 10 numeros");
        int pares = 0  ;
        int impares = 0 ; 

        int[] ALMACEN2 = new int[10];

        for (int i = 0; i < ALMACEN2.Length; i++)
        {

            ALMACEN2[i] = Convert.ToInt32(Console.ReadLine()); //LOS INSERTE EN UN ARREGLO

        }
   
       

        for (int i = 0; i < ALMACEN2.Length; i++)
        {

            if (ALMACEN2[i] % 2 == 0 ){
                pares ++ ;
            }
            else {
                impares ++ ; 
            }
        }

System.Console.WriteLine("Estos son los numero impares " + pares);
System.Console.WriteLine("Eston son los numeros impares" + " " + impares);
Console.ReadKey();

      


}}
