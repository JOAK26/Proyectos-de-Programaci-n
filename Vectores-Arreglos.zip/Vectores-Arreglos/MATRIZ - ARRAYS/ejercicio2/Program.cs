﻿//PROGRAMA QUE RECIBA 7 NÚMEROS DE PARTE DEL USUARIO. DEBE VERIFICAR SI DENTRO DE ELLOS ESTA EL 23. EN CASO DE QUE ASÍ SEA, MOSTRAR UN SALUDO Y SALIR. EN CASO CONTRARIO MOSTRAR UNA DESPEDIDA Y SALIR.


using System;
using System.ComponentModel.DataAnnotations;

class Program
{
    public static void Main()
    {

        System.Console.WriteLine("Escriba 7 numeros");

        int[] ALMACEN1 = new int[7];

        for (int i = 0; i < ALMACEN1.Length; i++)
        {

            ALMACEN1[i] = Convert.ToInt32(Console.ReadLine());

        }

        bool encontrado = false;

        for (int i = 0; i < ALMACEN1.Length; i++)
        {

            if (ALMACEN1[i] == 23)
            {
                encontrado = true;
                break;
            }
        }


        if (encontrado)
        {

            System.Console.WriteLine("SALUDO");
        }
        else
        {

            System.Console.WriteLine("BYE");
        }
    }


}
